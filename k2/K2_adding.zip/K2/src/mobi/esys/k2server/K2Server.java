package mobi.esys.k2server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.util.Log;

public class K2Server {
	public static JSONObject getJSONFromURL(final String method,
			final String postfix) {

		InputStream inputStream = new InputStream() {

			@Override
			public int read() {
				return 0;
			}
		};
		String result = "";
		JSONObject jsonObject = new JSONObject();

		try {

			inputStream = new DefaultHttpClient()
					.execute(
							new HttpGet("http://icu.im/rhymevideo/api/"
									+ method + ".json" + postfix)).getEntity()
					.getContent();

			final BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(inputStream));
			final StringBuilder stringBuilder = new StringBuilder();
			String line = "";

			while (line != null) {
				line = bufferedReader.readLine();
				stringBuilder.append(line + "\n");
			}

			inputStream.close();

			result = stringBuilder.toString();

			jsonObject = new JSONObject(result);
			Log.d("result", jsonObject.toString());
		} catch (Exception Exception) {

		}

		return jsonObject;
	}

	public Bundle getVideoJSONData() {
		JSONObject jsonObject = getJSONFromURL("videolist", "");
		Log.d("json", jsonObject.toString());
		Bundle videoListBundle = new Bundle();
		String[] urls = { "" };
		String[] md5s = { "" };
		try {
			JSONArray array = jsonObject.getJSONArray("result");
			urls = new String[array.length()];
			md5s = new String[array.length()];

			for (int i = 0; i < array.length(); i++) {
				JSONObject currVidList = array.getJSONObject(i);
				urls[i] = currVidList.getString("file_webpath");
				md5s[i] = currVidList.getJSONObject("file").getString("md5");
			}

			videoListBundle.putStringArray("urls", urls);
			videoListBundle.putStringArray("md5s", md5s);
			Log.d("urls", Arrays.toString(urls));
			Log.d("md5s", Arrays.toString(md5s));
		} catch (Exception e) {
		}

		return videoListBundle;
	}

	public static JSONObject postJSONFromURL(final String method,
			final String postfix) {

		InputStream inputStream = new InputStream() {

			@Override
			public int read() {
				return 0;
			}
		};
		String result = "";
		JSONObject jsonObject = new JSONObject();

		try {

			inputStream = new DefaultHttpClient()
					.execute(
							new HttpPost("http://icu.im/rhymevideo/api/"
									+ method + ".json" + postfix)).getEntity()
					.getContent();

			final BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(inputStream));
			final StringBuilder stringBuilder = new StringBuilder();
			String line = "";

			while (line != null) {
				line = bufferedReader.readLine();
				stringBuilder.append(line + "\n");
			}

			inputStream.close();

			result = stringBuilder.toString();

			jsonObject = new JSONObject(result);
			Log.d("result", jsonObject.toString());
		} catch (Exception Exception) {

		}

		return jsonObject;
	}

	public JSONObject doRequest(final String method, final JSONObject params) {

		InputStream inputStream = new InputStream() { // NOPMD by ���� on
														// 03.06.13 13:02

			@Override
			public int read() throws IOException {
				return 0;
			}
		};

		String result = "";
		JSONObject jsonObject = new JSONObject();

		try {
			final HttpClient httpClient = new DefaultHttpClient();
			final HttpPost httpPost = new HttpPost(
					"http://icu.im/rhymevideo/api/" + method + ".json");
			httpPost.setHeader(HTTP.CONTENT_TYPE, "application/json");
			StringEntity stringEntity;

			if (params != null) {
				stringEntity = new StringEntity(params.toString());

				stringEntity.setContentEncoding(new BasicHeader(
						HTTP.CONTENT_TYPE, "application/json"));
				httpPost.setEntity(stringEntity);
			}

			final HttpResponse httpResponse = httpClient.execute(httpPost);
			final HttpEntity httpEntity = httpResponse.getEntity();

			inputStream = httpEntity.getContent();

			final BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(inputStream));
			final StringBuilder stringBuilder = new StringBuilder();
			String line = "";

			while (line != null) {
				line = bufferedReader.readLine();
				stringBuilder.append(line + "\n");
			}

			result = stringBuilder.toString();

			jsonObject = new JSONObject(result);
			Log.d("result json", jsonObject.toString());
		} catch (Exception Exception) {
			Log.d("Parsing exception", "Error on JSON Parsing");
		}

		Log.d("result json", jsonObject.toString());
		return jsonObject;

	}

	/**
	 * /api/senddata.{_format} ���������� ���������� �� ������. ����: event -
	 * ��� ������� device_id - id ���������� battery_charge_level - �������
	 * ������ ������� signal_level - ������� ������� (GSM) power_supply -
	 * ������� latitude - ������ longitude - �������
	 *
	 * @throws Exception
	 */
	public void sendDataToServer(Bundle sendParams) {
		// JSONObject getUserStatusParams = new JSONObject();
		// try {
		// getUserStatusParams.put("device_id",
		// sendParams.getString("device_id"));
		// getUserStatusParams.put("battery_charge_level",
		// sendParams.getString("battery_charge_level"));
		// getUserStatusParams.put("signal_level",
		// sendParams.getString("signal_level"));
		// getUserStatusParams.put("power_supply",
		// sendParams.getString("power_supply"));
		// getUserStatusParams.put("latitude",
		// sendParams.getString("latitude"));
		// getUserStatusParams.put("longitude",
		// sendParams.getString("longitude"));
		// getUserStatusParams.put("longitude",
		// sendParams.getString("longitude"));
		// getUserStatusParams.put("video_name",
		// sendParams.getString("video_name"));
		// doRequest("sendplaylist", getUserStatusParams);
		// } catch (JSONException e) {
		// e.printStackTrace();
		// }

		postJSONFromURL(
				"sendplaylist",
				"?device_id=" + sendParams.getString("device_id")
						+ "&battery_charge_level="
						+ sendParams.getString("battery_charge_level")
						+ "&signal_level="
						+ sendParams.getString("signal_level")
						+ "&power_supply="
						+ sendParams.getString("power_supply") + "&latitude="
						+ sendParams.getString("latitude") + "&longitude="
						+ sendParams.getString("longitude") + "&video_name"
						+ sendParams.getString("video_name"));

	}
}
