package mobi.esys.tasks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

import mobi.esys.k2server.K2Server;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

public class DeleteFilesTask extends AsyncTask<String[], Void, Void> {
	private transient Context context;
	private transient K2Server server;
	private transient String[] urlsNames;

	// private transient String[] serverUrls;

	public DeleteFilesTask(Context context) {
		this.context = context;
		this.server = new K2Server();
	}

	@Override
	protected Void doInBackground(String[]... params) {
		try {
			md5Checks(params[0]);
		} catch (Exception e) {
		}
		return null;
	}

	public void md5Checks(String[] urls) throws Exception {
		File videoDir = new File(Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/K2Temp/");

		urlsNames = new String[urls.length];

		Log.d("delete urls", Arrays.asList(urls).toString());

		for (int j = 0; j < urls.length; j++) {
			urlsNames[j] = urls[j].substring(37, urls[j].length());
		}

		File[] files = videoDir.listFiles();
		if (urlsNames != null || urlsNames.length != 0) {
			for (int i = 0; i < files.length; i++) {
				// if (!md5s[i].equals(getMD5Checksum(files[i].getPath()))

				if (!Arrays.asList(urlsNames).contains(files[i].getName())) {
					files[i].delete();
				}

			}
		}

	}

	@Override
	protected void onPostExecute(Void result) {

		super.onPostExecute(result);
	}

	private void moveFiles() {
		File videoDir = new File(Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/K2Temp/");

		File endDir = new File(Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/K2Videos/");

		if (!Arrays.asList(endDir).equals(videoDir)) {
			try {
				copyDirectory(videoDir, endDir);
			} catch (Exception e) {
			}
		}
	}

	public void copyDirectory(File sourceLocation, File targetLocation)
			throws IOException {

		if (sourceLocation.isDirectory()) {
			if (!targetLocation.exists() && !targetLocation.mkdirs()) {
				throw new IOException("Cannot create dir "
						+ targetLocation.getAbsolutePath());
			}

			String[] children = sourceLocation.list();
			for (int i = 0; i < children.length; i++) {
				copyDirectory(new File(sourceLocation, children[i]), new File(
						targetLocation, children[i]));
			}
		} else {

			// make sure the directory we plan to store the recording in exists
			File directory = targetLocation.getParentFile();
			if (directory != null && !directory.exists() && !directory.mkdirs()) {
				throw new IOException("Cannot create dir "
						+ directory.getAbsolutePath());
			}

			InputStream in = new FileInputStream(sourceLocation);
			OutputStream out = new FileOutputStream(targetLocation);

			// Copy the bits from instream to outstream
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		}
	}
}
