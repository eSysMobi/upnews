package mobi.esys.tasks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;

import mobi.esys.k2.VideoActivity;
import mobi.esys.k2server.K2Server;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;

public class GetPlaylistTask extends AsyncTask<String[], Void, Void> {
	private transient K2Server server;
	private transient Context context;
	String[] md5s;

	public GetPlaylistTask(Context context) {
		server = new K2Server();
		this.context = context;
	}

	@Override
	protected Void doInBackground(String[]... params) {
		if (isNetworkAvailable(context)) {
			File videoDir = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/K2Videos/");

			Bundle servBundle = server.getVideoJSONData();
			String[] urls = servBundle.getStringArray("urls");
			md5s = servBundle.getStringArray("md5s");
			((VideoActivity) context).setMd5s(md5s);
			((VideoActivity) context).setNewUrls(urls);
			String[] urlsNames = new String[urls.length];
			for (int i = 0; i < urls.length; i++) {
				urlsNames[i] = urls[i].substring(37, urls[i].length());
			}

			File[] tempDirFiles = videoDir.listFiles();
			String[] fileNames = new String[tempDirFiles.length];
			for (int i = 0; i < tempDirFiles.length; i++) {
				fileNames[i] = tempDirFiles[i].getName();
			}
			if (!Arrays.asList(urlsNames).equals(fileNames))
				((VideoActivity) context).setDownloadComplete(false);
			for (int i = 0; i < urlsNames.length; i++) {
				if (!Arrays.asList(tempDirFiles).contains(urlsNames[i])) {

					InputStream is = null;

					URL url;
					try {
						url = new URL(urls[i]);
						final HttpURLConnection urlConnection = (HttpURLConnection) url
								.openConnection();
						urlConnection.setRequestMethod("GET");
						urlConnection.setDoOutput(true);
						urlConnection.connect();
						is = urlConnection.getInputStream();

						File tempFile = new File(videoDir, urlsNames[i]);
						if (!tempFile.exists()) {
							writeFile(is, tempFile);
							// if (Arrays.asList(md5s).contains(
							// getMD5Checksum(tempFile.getPath()))) {
							// File file = new File(Environment
							// .getExternalStorageDirectory()
							// .getAbsolutePath()
							// + "/K2Videos/", tempFile.getName());
							// if (!file.exists()) {
							// tempFile.renameTo(file);
							// }
							// }
						} else {
							if (!Arrays.asList(md5s).contains(
									getMD5Checksum(tempFile.getPath()))) {
								writeFile(is, tempFile);
								// if (Arrays.asList(md5s).contains(
								// getMD5Checksum(tempFile.getPath()))) {
								// File file = new File(Environment
								// .getExternalStorageDirectory()
								// .getAbsolutePath()
								// + "/K2Videos/", tempFile.getName());
								// if (!file.exists()) {
								// tempFile.renameTo(file);
								// }
								// }
							}

						}

					} catch (Exception e) {
					}

				}
			}
		}
		return null;
	}

	private void writeFile(InputStream is, File tempFile) throws Exception {
		tempFile.createNewFile();

		FileOutputStream fos = new FileOutputStream(tempFile);
		byte[] buffer = new byte[1024];
		int len1 = 0;

		if (is != null) {
			while ((len1 = is.read(buffer)) > 0) {
				fos.write(buffer, 0, len1);

			}
		}
		if (fos != null) {
			fos.close();
		}

	}

	public boolean isTheSame(String[] arr1, String[] arr2) {
		if (arr1.length != arr2.length)
			return false;
		for (int i = 0; i < arr1.length; i++)
			if (!arr1[i].equals(arr2[i]))
				return false;
		return true;
	}

	private boolean isNetworkAvailable(Context context) {
		if (context == null) {
			return false;
		}
		ConnectivityManager connectivityManager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		try {
			NetworkInfo activeNetworkInfo = connectivityManager
					.getActiveNetworkInfo();
			if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	private static byte[] createChecksum(String filename) throws Exception {
		InputStream fis = new FileInputStream(filename);

		byte[] buffer = new byte[1024];
		MessageDigest complete = MessageDigest.getInstance("MD5");
		int numRead;

		do {
			numRead = fis.read(buffer);
			if (numRead > 0) {
				complete.update(buffer, 0, numRead);
			}
		} while (numRead != -1);

		fis.close();
		return complete.digest();
	}

	private static String getMD5Checksum(String filename) throws Exception {
		byte[] b = createChecksum(filename);
		String result = "";

		for (int i = 0; i < b.length; i++) {
			result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1);
		}
		return result;
	}

	@Override
	protected void onPostExecute(Void result) {
		((VideoActivity) context).setDownloadComplete(true);
		super.onPostExecute(result);
	}
}
