package mobi.esys.tasks;

import mobi.esys.k2server.K2Server;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;

public class SendDataTask extends AsyncTask<Bundle, Void, Void> {
	private transient K2Server server;
	private transient Context context;

	public SendDataTask() {
		server = new K2Server();
	}

	@Override
	protected Void doInBackground(Bundle... params) {

		server.sendDataToServer(params[0]);

		return null;
	}

	private boolean isNetworkAvailable(Context context) {
		if (context == null) {
			return false;
		}
		ConnectivityManager connectivityManager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		try {
			NetworkInfo activeNetworkInfo = connectivityManager
					.getActiveNetworkInfo();
			if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

}
