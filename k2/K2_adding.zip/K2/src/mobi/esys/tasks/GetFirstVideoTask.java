package mobi.esys.tasks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

import mobi.esys.k2server.K2Server;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

public class GetFirstVideoTask extends AsyncTask<Void, Void, Void> {

	private transient K2Server server;
	private transient Context context;
	private String[] md5s;

	public GetFirstVideoTask(Context context) {
		this.context = context;
		this.server = new K2Server();
	}

	@Override
	protected Void doInBackground(Void... params) {

		if (isNetworkAvailable(context)) {
			md5s = server.getVideoJSONData().getStringArray("md5");
			File videoDir = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/K2Videos/");

			videoFromUrlToDisk(
					server.getVideoJSONData().getStringArray("urls")[0], 0);

		}
		return null;
	}

	public void videoFromUrlToDisk(final String vidURL, final int index) {

		InputStream is = null;
		try {

			final URL url = new URL(vidURL);
			final HttpURLConnection urlConnection = (HttpURLConnection) url
					.openConnection();
			urlConnection.setRequestMethod("GET");
			urlConnection.setDoOutput(true);
			urlConnection.connect();
			is = urlConnection.getInputStream();

			Uri u = Uri.parse(vidURL);
			Log.d("file  name", u.toString());
			File f = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/K2Videos/", vidURL.substring(37,
					vidURL.length()));
			if (!f.exists()) {
				f.createNewFile();

				FileOutputStream fos = new FileOutputStream(f);
				byte[] buffer = new byte[1024];
				int len1 = 0;

				if (is != null) {
					while ((len1 = is.read(buffer)) > 0) {
						fos.write(buffer, 0, len1);

					}
				}
				if (fos != null) {
					fos.close();
				}
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException ioe) {
				// just going to ignore this one
			}
		}

	}

	private static byte[] createChecksum(String filename) throws Exception {
		InputStream fis = new FileInputStream(filename);

		byte[] buffer = new byte[1024];
		MessageDigest complete = MessageDigest.getInstance("MD5");
		int numRead;

		do {
			numRead = fis.read(buffer);
			if (numRead > 0) {
				complete.update(buffer, 0, numRead);
			}
		} while (numRead != -1);

		fis.close();
		return complete.digest();
	}

	private static String getMD5Checksum(String filename) throws Exception {
		byte[] b = createChecksum(filename);
		String result = "";

		for (int i = 0; i < b.length; i++) {
			result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1);
		}
		return result;
	}

	private boolean isNetworkAvailable(Context context) {
		if (context == null) {
			return false;
		}
		ConnectivityManager connectivityManager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		try {
			NetworkInfo activeNetworkInfo = connectivityManager
					.getActiveNetworkInfo();
			if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
				return true;
			}
		} catch (Exception e) {

		}

		return false;
	}

	public boolean isTheSame(String[] arr1, String[] arr2) {
		if (arr1.length != arr2.length)
			return false;
		for (int i = 0; i < arr1.length; i++)
			if (!arr1[i].equals(arr2[i]))
				return false;
		return true;
	}

	// files = videoDir.listFiles();
	//
	// for (int i = 1; i < files.length; i++) {
	// String rightName = Environment.getExternalStorageDirectory()
	// .getAbsolutePath()
	// + "/K2Videos/"
	// + "video"
	// + (i + 1)
	// + ".mp4";
	// if (!rightName.equals(files[i + 1].getPath())) {
	// File rightFile = new File(rightName);
	// files[i].renameTo(rightFile);
	// }
}
