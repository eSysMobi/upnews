package mobi.esys.tasks;

import mobi.esys.k2server.K2Server;
import android.os.AsyncTask;
import android.os.Bundle;

public class GetVideoDataTask extends AsyncTask<Void, Void, Bundle> {
	private transient K2Server server;

	public GetVideoDataTask() {
		this.server = new K2Server();
	}

	@Override
	protected Bundle doInBackground(Void... params) {
		return server.getVideoJSONData();
	}

}
