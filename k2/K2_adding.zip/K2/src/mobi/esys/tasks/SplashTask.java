package mobi.esys.tasks;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import mobi.esys.k2.SplashActivity;
import mobi.esys.k2server.K2Server;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

public class SplashTask extends AsyncTask<Void, Void, Bundle> {
	private transient K2Server server;
	private transient Context context;

	public SplashTask(Context context) {
		this.server = new K2Server();
		this.context = context;
	}

	@Override
	protected Bundle doInBackground(Void... params) {
		Bundle videoDataBundle = new Bundle();
		File videoDir = new File(Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/K2Videos/");
		// File videoTemp = new File(Environment.getExternalStorageDirectory()
		// .getAbsolutePath() + "/K2Temp/");
		ArrayList<String> fileList = new ArrayList<String>();
		Bundle videoList = server.getVideoJSONData();

		Log.d("task urls", Arrays.toString(videoList.getStringArray("urls")));
		videoDataBundle
				.putStringArray("urls", videoList.getStringArray("urls"));
		videoDataBundle
				.putStringArray("md5s", videoList.getStringArray("md5s"));

		if (!videoDir.exists()) {

			videoDir.mkdirs();

			videoFromUrlToDisk(videoList.getStringArray("urls")[0]);

			File[] files = videoDir.listFiles();
			fileList.clear();
			for (File file : files) {
				fileList.add(file.getPath());
			}
			videoDataBundle.putStringArrayList("files", fileList);
		} else {
			File[] files = videoDir.listFiles();
			fileList.clear();
			for (File file : files) {
				fileList.add(file.getPath());
			}
			videoDataBundle.putStringArrayList("files", fileList);

		}

		return videoDataBundle;
	}

	public void videoFromUrlToDisk(final String vidURL) {

		InputStream is = null;
		try {

			final URL url = new URL(vidURL);
			final HttpURLConnection urlConnection = (HttpURLConnection) url
					.openConnection();
			urlConnection.setRequestMethod("GET");
			urlConnection.setDoOutput(true);
			urlConnection.connect();
			is = urlConnection.getInputStream();

			Uri u = Uri.parse(vidURL);
			Log.d("file  name", u.toString());
			File f = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/K2Videos/", vidURL.substring(37,
					vidURL.length()));
			if (!f.exists()) {
				f.createNewFile();

				FileOutputStream fos = new FileOutputStream(f);
				byte[] buffer = new byte[1024];
				int len1 = 0;

				if (is != null) {
					while ((len1 = is.read(buffer)) > 0) {
						fos.write(buffer, 0, len1);

					}
				}
				if (fos != null) {
					fos.close();

				}
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (is != null) {
					is.close();

				}
			} catch (IOException ioe) {
				// just going to ignore this one
			}
		}

	}

	@Override
	protected void onPostExecute(Bundle result) {
		super.onPostExecute(result);
		((SplashActivity) context).start();
	}
}
