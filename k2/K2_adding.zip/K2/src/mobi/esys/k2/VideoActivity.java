package mobi.esys.k2;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.acl.LastOwnerException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

import mobi.esys.tasks.DeleteFilesTask;
import mobi.esys.tasks.GetInternetVideoTask;
import mobi.esys.tasks.GetPlaylistTask;
import mobi.esys.tasks.SendDataTask;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings.Secure;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoActivity extends Activity {
	private transient List<String> fileList;
	private transient int videoIndex = 0;
	private transient VideoView videoView;
	TelephonyManager Tel;
	private transient boolean isDownload = true;

	String signalStrengthText = "";
	private String[] md5s = {};

	private transient String lon = "0.0";
	private transient String lat = "0.0";

	private transient Bundle playListBundle;

	private transient GetInternetVideoTask getInternetVideoTask;

	private transient String signalStrengthString = "";
	private transient SignalStrengthListener phoneStateListener;

	private transient boolean isDownloadComplete = false;

	private transient String[] newUrls;

	String lastVideo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video_layout);

		videoView = (VideoView) findViewById(R.id.videoView1);
		fileList = new ArrayList<String>();

		this.registerReceiver(this.mConnReceiver, new IntentFilter(
				ConnectivityManager.CONNECTIVITY_ACTION));
		Tel = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

		File videoDir = new File(Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/K2Videos/");

		File[] files = videoDir.listFiles();
		fileList.clear();
		for (File file : files) {
			fileList.add(file.getPath());
		}

		Log.d("md5 videos", Arrays.toString(md5s));

		phoneStateListener = new SignalStrengthListener();
		Tel.listen(phoneStateListener,
				PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);

		LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		Criteria myCriteria = new Criteria();
		myCriteria.setPowerRequirement(Criteria.POWER_LOW);
		// let Android select the right location provider for you
		// String myProvider = lm.getBestProvider(myCriteria, true);

		// finally require updates at -at least- the desired rate
		long minTimeMillis = 600000; // 600,000 milliseconds make 10 minutes
		lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
				minTimeMillis, 0, mLocationListener);

		getInternetVideoTask = new GetInternetVideoTask(VideoActivity.this);
		getInternetVideoTask.execute(getIntent().getExtras());
		isDownload = true;

		Uri video2 = Uri.parse(fileList.get(videoIndex));
		videoView.setMediaController(new MediaController(this));
		videoView.setVideoURI(video2);

		String[] md5Files = new String[fileList.size()];
		for (int i = 0; i < md5Files.length; i++) {
			try {
				md5Files[i] = getMD5Checksum(fileList.get(i));
			} catch (Exception e) {
			}

		}

		videoView.setOnPreparedListener(new OnPreparedListener() {

			@Override
			public void onPrepared(MediaPlayer mp) {
				if (isDownloadComplete()) {
					GetPlaylistTask getPlaylistTask = new GetPlaylistTask(
							VideoActivity.this);
					getPlaylistTask.execute();
				}

				File videoDir = new File(Environment
						.getExternalStorageDirectory().getAbsolutePath()
						+ "/K2Videos/");
				List<String> current_files = new ArrayList<String>();
				File[] files = videoDir.listFiles();
				fileList.clear();

				for (File file : files) {

					current_files.add(file.getPath());

				}

				fileList.clear();
				fileList.addAll(current_files);

				String[] md5Files = new String[fileList.size()];
				for (int i = 0; i < md5Files.length; i++) {
					try {
						md5Files[i] = getMD5Checksum(fileList.get(i));
					} catch (Exception e) {
					}
				}
				lastVideo = fileList.get(videoIndex);
				if (videoIndex == fileList.size() - 1) {
					videoIndex = 0;

				} else {
					videoIndex++;

				}

			}

		});

		videoView.start();

		videoView.setOnCompletionListener(new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer mp) {

				IntentFilter ifilter = new IntentFilter(
						Intent.ACTION_BATTERY_CHANGED);
				Intent batteryStatus = VideoActivity.this.registerReceiver(
						null, ifilter);

				int level = batteryStatus.getIntExtra(
						BatteryManager.EXTRA_LEVEL, -1);

				int status = batteryStatus.getIntExtra(
						BatteryManager.EXTRA_STATUS, -1);

				boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
						|| status == BatteryManager.BATTERY_STATUS_FULL;

				/**
				 * /api/senddata.{_format} ���������� ���������� �� ������.
				 * ����: event - ��� ������� device_id - id ����������
				 * battery_charge_level - ������� ������ ������� signal_level -
				 * ������� ������� (GSM) power_supply - ������� latitude -
				 * ������ longitude - �������
				 */

				String serial = null;

				try {
					Class<?> c = Class.forName("android.os.SystemProperties");
					Method get = c.getMethod("get", String.class);
					serial = (String) get.invoke(c, "ro.serialno");
				} catch (Exception ignored) {
				}

				Bundle sendToServerBundle = new Bundle();

				sendToServerBundle.putString("device_id", serial);
				sendToServerBundle.putString("battery_charge_level",
						String.valueOf(level));
				sendToServerBundle.putString("power_supply",
						String.valueOf(isCharging));
				sendToServerBundle.putString("signal_level",
						signalStrengthString);
				sendToServerBundle.putString("longitude", lon);
				sendToServerBundle.putString("latitude", lat);
				sendToServerBundle.putString("video_name",
						lastVideo.substring(37, lastVideo.length()));
				Log.d("send params", sendToServerBundle.toString());

				// SendDataTask dataTask = new SendDataTask();
				// dataTask.execute(sendToServerBundle);

				ImageView imageView = (ImageView) findViewById(R.id.imageView1);

				final Animation rotAnim = AnimationUtils.loadAnimation(
						VideoActivity.this, R.anim.rotate);
				imageView.startAnimation(rotAnim);

				try {
					if (Arrays.asList(getMd5s()).contains(
							getMD5Checksum(fileList.get(videoIndex)))) {
						Uri video2 = Uri.parse(fileList.get(videoIndex));
						videoView.setVideoURI(video2);
						videoView.start();
						rotAnim.cancel();
					} else {
						Uri video2 = Uri.parse(fileList.get(0));
						videoView.setVideoURI(video2);
						videoView.start();
						rotAnim.cancel();
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// if (isDownloadComplete) {
				// DeleteFilesTask deleteFilesTask = new DeleteFilesTask(
				// VideoActivity.this);
				// deleteFilesTask.execute(getNewUrls());
				// }

			}
		});
	}

	public static byte[] createChecksum(String filename) throws Exception {
		InputStream fis = new FileInputStream(filename);

		byte[] buffer = new byte[1024];
		MessageDigest complete = MessageDigest.getInstance("MD5");
		int numRead;

		do {
			numRead = fis.read(buffer);
			if (numRead > 0) {
				complete.update(buffer, 0, numRead);
			}
		} while (numRead != -1);

		fis.close();
		return complete.digest();
	}

	public static String getMD5Checksum(String filename) throws Exception {
		byte[] b = createChecksum(filename);
		String result = "";

		for (int i = 0; i < b.length; i++) {
			result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1);
		}
		return result;
	}

	public void stopDownload() {
		if (isDownload) {
			getInternetVideoTask.cancel(true);
			getInternetVideoTask = null;

			isDownload = false;
		}
	}

	public void restartDownload(Bundle restartBundle) {
		if (!isDownload) {
			getInternetVideoTask = new GetInternetVideoTask(this);
			getInternetVideoTask.execute(restartBundle);

			isDownload = true;
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		this.unregisterReceiver(mConnReceiver);
	}

	private BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			boolean noConnectivity = intent.getBooleanExtra(
					ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);
			String reason = intent
					.getStringExtra(ConnectivityManager.EXTRA_REASON);
			boolean isFailover = intent.getBooleanExtra(
					ConnectivityManager.EXTRA_IS_FAILOVER, false);

			NetworkInfo currentNetworkInfo = (NetworkInfo) intent
					.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
			NetworkInfo otherNetworkInfo = (NetworkInfo) intent
					.getParcelableExtra(ConnectivityManager.EXTRA_OTHER_NETWORK_INFO);

			if (currentNetworkInfo.isConnected()) {
				restartDownload(playListBundle);
			} else {
				stopDownload();
			}
		}
	};

	public void refreshPlaylist(Bundle refreshPlaylistBundle) {

		stopDownload();
		restartDownload(refreshPlaylistBundle);
		md5s = refreshPlaylistBundle.getStringArray("md5s");

	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		finish();
	}

	private class SignalStrengthListener extends PhoneStateListener {
		@Override
		public void onSignalStrengthsChanged(SignalStrength signalStrength) {

			signalStrengthString = String.valueOf(signalStrength
					.getGsmSignalStrength());

			super.onSignalStrengthsChanged(signalStrength);
		}
	}

	@Override
	protected void onStop() {
		videoView.stopPlayback();
		Tel.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
		super.onStop();

	}

	@Override
	protected void onPause() {
		videoView.pause();
		Tel.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
		super.onPause();
	}

	@Override
	protected void onResume() {
		videoView.resume();
		Tel.listen(phoneStateListener,
				PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
		super.onResume();
	}

	private final LocationListener mLocationListener = new LocationListener() {
		@Override
		public void onLocationChanged(final Location location) {
			lon = String.valueOf(location.getLongitude());
			lat = String.valueOf(location.getLatitude());
		}

		@Override
		public void onProviderDisabled(String provider) {

		}

		@Override
		public void onProviderEnabled(String provider) {

		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {

		}
	};

	public void setVideoIndex(int index) {
		this.videoIndex = index;
	}

	public boolean isTheSame(String[] arr1, String[] arr2) {
		if (arr1.length != arr2.length)
			return false;
		for (int i = 0; i < arr1.length; i++)
			if (!arr1[i].equals(arr2[i]))
				return false;
		return true;
	}

	public boolean isDownloadComplete() {
		return isDownloadComplete;
	}

	public void setDownloadComplete(boolean isDownloadComplete) {
		this.isDownloadComplete = isDownloadComplete;
	}

	public String[] getNewUrls() {
		return newUrls;
	}

	public void setNewUrls(String[] newUrls) {
		this.newUrls = newUrls;
	}

	public String[] getMd5s() {
		return md5s;
	}

	public void setMd5s(String[] md5s) {
		this.md5s = md5s;
	}

}
