package mobi.esys.k2;

import java.io.File;
import java.util.ArrayList;

import mobi.esys.tasks.GetFirstVideoTask;
import mobi.esys.tasks.SplashTask;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Toast;

public class SplashActivity extends Activity {
	private transient ArrayList<String> fileList;
	Bundle splashBundle;
	ArrayList<String> newFilesList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_layout);
		SplashTask createFolderTask = new SplashTask(this);
		createFolderTask.execute();

		splashBundle = new Bundle();

		try {
			splashBundle = createFolderTask.get();

		} catch (Exception e) {

		}
		fileList = splashBundle.getStringArrayList("files");

		if (fileList.size() > 0) {
			Toast.makeText(this, "����� � ����� �� �����", Toast.LENGTH_LONG)
					.show();
			Intent videoActivityIntent = new Intent(SplashActivity.this,
					VideoActivity.class);

			videoActivityIntent.putExtras(splashBundle);
			startActivity(videoActivityIntent);
			finish();
		} else {

			Toast.makeText(this, "����� � ����� �����", Toast.LENGTH_LONG)
					.show();

			newFilesList = new ArrayList<String>();
			File dirF = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/K2Videos/");

			File[] files = dirF.listFiles();
			newFilesList.clear();
			for (File file : files) {
				newFilesList.add(file.getPath());
			}

		}
	}

	public void start() {
		Intent videoActivityIntent = new Intent(SplashActivity.this,
				VideoActivity.class);
		splashBundle.putStringArrayList("files", newFilesList);
		videoActivityIntent.putExtras(splashBundle);
		startActivity(videoActivityIntent);
	}

}
